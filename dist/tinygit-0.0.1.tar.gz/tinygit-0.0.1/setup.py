from setuptools import setup

setup(
	name='tinygit',
	version='0.0.1',
  packages=['tinygit'],
  entry_points={
    'console_scripts': [
      'tinygit=tinygit.cli:main'
    ]
  },
)
